// 内容脚本：在抖音页面上执行关注操作
// 使用IIFE避免重复加载导致的变量重复声明错误
(function() {
  'use strict';
  
  // 检查是否已经加载过，避免重复执行
  if (window.douyinAutoFollowLoaded) {
    console.log('抖音自动关注脚本已加载，跳过重复加载');
    return;
  }
  window.douyinAutoFollowLoaded = true;

let isFollowing = false;
let followQueue = [];
let currentIndex = 0;
let followInterval = null;
let followIntervalMs = 5000;

// 获取已关注用户列表
async function getFollowedUsers() {
  const result = await chrome.storage.local.get(['followedUsers']);
  return result.followedUsers || [];
}

// 添加已关注用户
async function addFollowedUser(url) {
  const followedUsers = await getFollowedUsers();
  if (!followedUsers.includes(url)) {
    followedUsers.push(url);
    await chrome.storage.local.set({ followedUsers });
  }
}

// 检查用户是否已关注
async function isUserFollowed(url) {
  const followedUsers = await getFollowedUsers();
  return followedUsers.includes(url);
}

// 获取网络时间（优先使用background script代理，避免CORS问题）
async function getNetworkTime() {
  try {
    // 首先尝试通过background script代理获取（避免CORS问题）
    const response = await chrome.runtime.sendMessage({ action: 'getNetworkTime' });
    if (response && response.success && response.time) {
      logger.info(`通过background script获取网络时间: ${response.time}`);
      return response.time;
    }
  } catch (error) {
    logger.warning(`通过background script获取时间失败: ${error.message}`);
  }
  
  // 如果代理失败，尝试直接请求（可能受CORS限制）
  const TIME_APIS = [
    'https://api.uuni.cn/api/time',
    'http://vv.video.qq.com/checktime?otype=json'
  ];
  
  for (const api of TIME_APIS) {
    try {
      const response = await fetch(api, {
        method: 'GET',
        mode: 'cors',
        cache: 'no-cache'
      });
      
      if (!response.ok) {
        logger.warning(`API ${api} 返回错误: ${response.status}`);
        continue;
      }
      
      let data;
      
      if (api.includes('qq.com')) {
        const text = await response.text();
        const jsonMatch = text.match(/QZOutputJson=({.+})/);
        if (jsonMatch) {
          data = JSON.parse(jsonMatch[1]);
          if (data.t) {
            logger.info(`从 ${api} 获取时间成功: ${data.t}`);
            return data.t;
          }
        }
      } else {
        data = await response.json();
        if (data.timestamp) {
          logger.info(`从 ${api} 获取时间成功: ${data.timestamp}`);
          return data.timestamp;
        }
      }
    } catch (error) {
      // 静默处理错误，尝试下一个API
      logger.warning(`API ${api} 请求失败: ${error.message}`);
      continue;
    }
  }
  
  // 如果所有API都失败，使用本地时间作为备用
  logger.warning('所有时间API都不可用，使用本地时间');
  const localTime = Math.floor(Date.now() / 1000);
  logger.info(`使用本地时间: ${localTime}`);
  return localTime;
}

// 检查密钥是否过期
async function checkKeyExpiry(keyExpiry) {
  try {
    const currentTime = await getNetworkTime();
    return currentTime < keyExpiry;
  } catch (error) {
    console.error('检查密钥过期失败:', error);
    return false;
  }
}

// 保存执行状态
async function saveFollowState() {
  await chrome.storage.local.set({
    isFollowing: isFollowing,
    followQueue: followQueue,
    currentIndex: currentIndex,
    followIntervalMs: followIntervalMs
  });
}

// 恢复执行状态
async function restoreFollowState() {
  const result = await chrome.storage.local.get(['isFollowing', 'followQueue', 'currentIndex', 'followIntervalMs', 'keyExpiry', 'interval']);
  if (result.isFollowing && result.followQueue && result.followQueue.length > 0) {
    logger.info('检测到未完成的关注任务，正在恢复...');
    isFollowing = result.isFollowing;
    followQueue = result.followQueue;
    currentIndex = result.currentIndex || 0;
    followIntervalMs = result.followIntervalMs || 5000;
    
    // 继续执行
    if (isFollowing && currentIndex < followQueue.length) {
      const url = followQueue[currentIndex];
      const currentUrl = window.location.href.split('?')[0];
      const targetUrl = url.split('?')[0];
      
      logger.info(`恢复执行，当前页面: ${currentUrl}`);
      logger.info(`目标页面: ${targetUrl}`);
      
      // 如果当前页面就是目标页面，说明导航已完成，继续处理
      if (currentUrl === targetUrl) {
        logger.info('已在目标页面，继续处理关注操作...');
        setTimeout(async () => {
          await processCurrentUser(url, result.keyExpiry, currentIndex, followQueue.length, result.interval || 5);
        }, 3000);
      } else {
        // 如果不在目标页面，说明导航可能失败或还未完成，等待一下再检查
        logger.warning('当前页面与目标页面不匹配，等待页面加载...');
        setTimeout(async () => {
          const newUrl = window.location.href.split('?')[0];
          if (newUrl === targetUrl) {
            logger.info('页面已加载到目标页面，继续处理...');
            await processCurrentUser(url, result.keyExpiry, currentIndex, followQueue.length, result.interval || 5);
          } else {
            logger.error('页面导航失败，重新导航...');
            await navigateToUser(url);
          }
        }, 2000);
      }
    }
  }
}

// 处理当前用户（在页面加载完成后）
async function processCurrentUser(url, keyExpiry, index, total, interval) {
  // 从存储中恢复统计信息
  const statsResult = await chrome.storage.local.get(['successCount', 'failCount']);
  let successCount = statsResult.successCount || 0;
  let failCount = statsResult.failCount || 0;
  
  const result = await followUser(url, keyExpiry, index, total);
  
  if (result) {
    successCount++;
  } else {
    failCount++;
  }
  
  // 保存统计信息
  await chrome.storage.local.set({ successCount, failCount });
  
  currentIndex++;
  await saveFollowState();
  
  // 继续下一个
  if (isFollowing && currentIndex < followQueue.length) {
    const nextUrl = followQueue[currentIndex];
    logger.info(`等待 ${interval} 秒后处理下一个用户...`);
    followInterval = setTimeout(async () => {
      await navigateToUser(nextUrl);
    }, followIntervalMs);
  } else {
    logger.info('========== 关注流程完成 ==========');
    logger.info(`成功: ${successCount} 个`);
    logger.info(`失败: ${failCount} 个`);
    await chrome.storage.local.remove(['successCount', 'failCount']);
    stopFollow();
    await chrome.storage.local.remove(['isFollowing', 'followQueue', 'currentIndex', 'followIntervalMs']);
    sendMessage('updateStatus', `关注完成 (成功: ${successCount}, 失败: ${failCount})`, 'success');
    sendMessage('followComplete');
  }
}

// 导航到用户页面
async function navigateToUser(url) {
  // 保存状态
  await saveFollowState();
  logger.info(`导航到新页面: ${url}`);
  window.location.href = url;
  // 注意：页面导航后，脚本会重新加载，状态会通过restoreFollowState恢复
  // 这里不等待，让页面自然加载
}

// 模拟真实用户点击（更接近人工操作）
async function simulateHumanClick(element) {
  if (!element) return false;
  
  try {
    // 获取元素位置
    const rect = element.getBoundingClientRect();
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;
    
    // 模拟鼠标移动到按钮上
    const mouseOverEvent = new MouseEvent('mouseover', {
      view: window,
      bubbles: true,
      cancelable: true,
      clientX: x,
      clientY: y
    });
    element.dispatchEvent(mouseOverEvent);
    await new Promise(resolve => setTimeout(resolve, 100));
    
    // 模拟鼠标进入
    const mouseEnterEvent = new MouseEvent('mouseenter', {
      view: window,
      bubbles: true,
      cancelable: true,
      clientX: x,
      clientY: y
    });
    element.dispatchEvent(mouseEnterEvent);
    await new Promise(resolve => setTimeout(resolve, 100));
    
    // 模拟鼠标按下
    const mouseDownEvent = new MouseEvent('mousedown', {
      view: window,
      bubbles: true,
      cancelable: true,
      clientX: x,
      clientY: y,
      button: 0
    });
    element.dispatchEvent(mouseDownEvent);
    await new Promise(resolve => setTimeout(resolve, 50));
    
    // 模拟鼠标抬起
    const mouseUpEvent = new MouseEvent('mouseup', {
      view: window,
      bubbles: true,
      cancelable: true,
      clientX: x,
      clientY: y,
      button: 0
    });
    element.dispatchEvent(mouseUpEvent);
    await new Promise(resolve => setTimeout(resolve, 50));
    
    // 模拟点击事件
    const clickEvent = new MouseEvent('click', {
      view: window,
      bubbles: true,
      cancelable: true,
      clientX: x,
      clientY: y,
      button: 0
    });
    element.dispatchEvent(clickEvent);
    
    // 也尝试直接调用click方法（作为备用）
    element.click();
    
    await new Promise(resolve => setTimeout(resolve, 200));
    
    return true;
  } catch (error) {
    logger.error(`模拟点击失败: ${error.message}`);
    return false;
  }
}

// 查找并点击关注按钮
async function clickFollowButton() {
  logger.info('开始查找关注按钮...');
  
  // 等待页面加载完成（增加等待时间）
  await new Promise(resolve => setTimeout(resolve, 5000));
  
  // 多次尝试查找按钮（因为页面可能是动态加载的）
  let followButton = null;
  let attempts = 0;
  const maxAttempts = 5;
  
  while (!followButton && attempts < maxAttempts) {
    attempts++;
    logger.info(`第 ${attempts} 次尝试查找关注按钮...`);
    
    // 查找所有按钮
    const buttons = Array.from(document.querySelectorAll('button'));
    logger.info(`找到 ${buttons.length} 个按钮`);
    
    // 方法1: 通过文本内容查找
    for (const button of buttons) {
      const text = (button.textContent || button.innerText || '').trim();
      const ariaLabel = (button.getAttribute('aria-label') || '').trim();
      const title = (button.getAttribute('title') || '').trim();
      
      logger.info(`检查按钮: text="${text}", aria-label="${ariaLabel}", title="${title}"`);
      
      // 检查文本内容（更宽松的匹配）
      if ((text === '关注' || 
           (text.includes('关注') && !text.includes('已关注') && !text.includes('取消关注'))) ||
           ariaLabel === '关注' ||
           (ariaLabel.includes('关注') && !ariaLabel.includes('已关注')) ||
           title === '关注' ||
           (title.includes('关注') && !title.includes('已关注'))) {
        
        // 检查按钮是否可见且可点击
        const rect = button.getBoundingClientRect();
        const style = window.getComputedStyle(button);
        const isVisible = rect.width > 0 && 
                         rect.height > 0 && 
                         style.display !== 'none' && 
                         style.visibility !== 'hidden' &&
                         style.opacity !== '0' &&
                         !button.disabled;
        
        logger.info(`找到可能的关注按钮: text="${text}", visible=${isVisible}, rect=(${rect.left},${rect.top},${rect.width},${rect.height})`);
        
        if (isVisible) {
          followButton = button;
          logger.success(`找到关注按钮: ${text}`);
          break;
        }
      }
    }
    
    // 如果还没找到，等待一下再试
    if (!followButton && attempts < maxAttempts) {
      logger.info(`未找到关注按钮，等待2秒后重试...`);
      await new Promise(resolve => setTimeout(resolve, 2000));
    }
  }
  
  // 方法2: 如果还没找到，尝试通过类名或属性查找
  if (!followButton) {
    logger.info('尝试通过类名查找关注按钮...');
    const possibleSelectors = [
      'button[class*="follow"]',
      'button[class*="Follow"]',
      'div[class*="follow"] button',
      'div[class*="Follow"] button',
      '[role="button"][aria-label*="关注"]',
      'button:has-text("关注")'
    ];
    
    for (const selector of possibleSelectors) {
      try {
        const possibleButtons = document.querySelectorAll(selector);
        logger.info(`选择器 "${selector}" 找到 ${possibleButtons.length} 个元素`);
        
        for (const btn of possibleButtons) {
          const text = (btn.textContent || btn.innerText || '').trim();
          if (text.includes('关注') && 
              !text.includes('已关注') && 
              !text.includes('取消关注')) {
            const rect = btn.getBoundingClientRect();
            const style = window.getComputedStyle(btn);
            
            if (rect.width > 0 && 
                rect.height > 0 && 
                style.display !== 'none' && 
                style.visibility !== 'hidden') {
              followButton = btn;
              logger.success(`通过选择器找到关注按钮: ${selector}`);
              break;
            }
          }
        }
        if (followButton) break;
      } catch (e) {
        // 某些选择器可能不支持，忽略错误
      }
    }
  }
  
  if (followButton) {
    logger.info('找到关注按钮，准备点击...');
    
    // 滚动到按钮位置
    followButton.scrollIntoView({ behavior: 'smooth', block: 'center' });
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // 使用模拟真实用户点击
    logger.info('执行模拟点击...');
    const clicked = await simulateHumanClick(followButton);
    
    if (clicked) {
      logger.success('关注按钮点击成功');
      return true;
    } else {
      logger.error('模拟点击失败，尝试直接点击...');
      // 备用方案：直接点击
      try {
        followButton.click();
        await new Promise(resolve => setTimeout(resolve, 500));
        return true;
      } catch (error) {
        logger.error(`直接点击也失败: ${error.message}`);
        return false;
      }
    }
  } else {
    logger.error('未找到关注按钮');
    // 输出所有按钮信息用于调试
    const allButtons = Array.from(document.querySelectorAll('button'));
    logger.info(`页面共有 ${allButtons.length} 个按钮`);
    allButtons.forEach((btn, index) => {
      const text = (btn.textContent || btn.innerText || '').trim();
      if (text) {
        logger.info(`按钮${index}: "${text}"`);
      }
    });
    return false;
  }
}

// 处理单个用户关注
async function followUser(url, keyExpiry, index = 0, total = 0) {
  try {
    logger.info(`[${index + 1}/${total}] 开始处理用户: ${url}`);
    
    // 检查密钥是否过期
    logger.info('检查密钥是否过期...');
    logger.info(`传入的过期时间: ${keyExpiry}`);
    
    // 如果 keyExpiry 未传入，从存储中获取
    let actualKeyExpiry = keyExpiry;
    if (!actualKeyExpiry) {
      const storageResult = await chrome.storage.local.get(['keyExpiry']);
      actualKeyExpiry = storageResult.keyExpiry;
      logger.info(`从存储中获取过期时间: ${actualKeyExpiry}`);
    }
    
    if (!actualKeyExpiry) {
      logger.error('密钥过期时间未设置');
      sendMessage('updateStatus', '密钥过期时间未设置，请先检查密钥', 'error');
      stopFollow();
      return false;
    }
    
    const currentTime = await getNetworkTime();
    logger.info(`当前网络时间: ${currentTime}, 过期时间: ${actualKeyExpiry}`);
    
    const isValid = await checkKeyExpiry(actualKeyExpiry);
    if (!isValid) {
      logger.error(`密钥已过期 (当前时间: ${currentTime}, 过期时间: ${actualKeyExpiry})`);
      sendMessage('updateStatus', '密钥已过期，停止关注', 'error');
      stopFollow();
      return false;
    }
    logger.success('密钥检查通过');
    
    // 检查是否已关注
    logger.info('检查用户是否已关注...');
    const alreadyFollowed = await isUserFollowed(url);
    if (alreadyFollowed) {
      logger.warning(`用户已关注，跳过: ${url}`);
      sendMessage('updateProgress', `[${index + 1}/${total}] 跳过已关注: ${url}`);
      return true;
    }
    
    // 检查当前页面是否是目标页面
    const currentUrl = window.location.href.split('?')[0];
    const targetUrl = url.split('?')[0];
    
    if (currentUrl !== targetUrl) {
      // 导航到用户页面
      logger.info(`正在导航到用户页面: ${url}`);
      sendMessage('updateProgress', `[${index + 1}/${total}] 正在访问: ${url}`);
      await navigateToUser(url);
      // 注意：导航后脚本会重新加载，状态会通过restoreFollowState恢复
      // 这里返回false，让恢复逻辑继续处理
      return false;
    }
    
    logger.info('已在目标页面，等待内容加载...');
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // 点击关注按钮
    logger.info('查找并点击关注按钮...');
    const clicked = await clickFollowButton();
    if (clicked) {
      logger.success('关注按钮点击成功');
      await new Promise(resolve => setTimeout(resolve, 2000)); // 等待关注操作完成
      
      // 验证是否关注成功（检查按钮文本是否变为"已关注"）
      const buttons = Array.from(document.querySelectorAll('button'));
      let isFollowed = false;
      for (const btn of buttons) {
        const text = (btn.textContent || btn.innerText || '').trim();
        if (text.includes('已关注') || text.includes('取消关注')) {
          isFollowed = true;
          break;
        }
      }
      
      if (isFollowed) {
        await addFollowedUser(url);
        logger.success(`✓ 成功关注用户: ${url}`);
        sendMessage('updateProgress', `[${index + 1}/${total}] ✓ 已关注: ${url}`);
        return true;
      } else {
        logger.warning('关注按钮已点击，但状态未更新，可能关注失败');
        sendMessage('updateProgress', `[${index + 1}/${total}] ⚠ 关注状态未确认: ${url}`);
        return false;
      }
    } else {
      logger.error(`未找到关注按钮: ${url}`);
      sendMessage('updateProgress', `[${index + 1}/${total}] ✗ 未找到关注按钮: ${url}`);
      return false;
    }
  } catch (error) {
    logger.error(`关注用户失败: ${url} - ${error.message}`);
    console.error('关注用户失败:', error);
    sendMessage('updateProgress', `[${index + 1}/${total}] ✗ 关注失败: ${url} - ${error.message}`);
    return false;
  }
}

// 开始关注流程
async function startFollow(userList, interval, keyExpiry) {
  if (isFollowing) {
    logger.warning('关注流程已在运行中');
    return;
  }
  
  logger.info('========== 开始关注流程 ==========');
  logger.info(`关注间隔: ${interval}秒`);
  logger.info(`密钥过期时间: ${keyExpiry}`);
  
  // 如果没有传入过期时间，从存储中获取
  let actualKeyExpiry = keyExpiry;
  if (!actualKeyExpiry) {
    const result = await chrome.storage.local.get(['keyExpiry']);
    actualKeyExpiry = result.keyExpiry;
    logger.info(`从存储中获取过期时间: ${actualKeyExpiry}`);
  }
  
  if (!actualKeyExpiry) {
    logger.error('密钥过期时间未设置');
    sendMessage('updateStatus', '密钥过期时间未设置，请先检查密钥', 'error');
    return;
  }
  
  isFollowing = true;
  followQueue = userList.map(url => url.trim()).filter(url => url);
  currentIndex = 0;
  followIntervalMs = interval * 1000;
  
  // 保存配置和状态
  await chrome.storage.local.set({
    keyExpiry: actualKeyExpiry,
    interval
  });
  await saveFollowState();
  
  const totalUsers = followQueue.length;
  logger.info(`总共 ${totalUsers} 个用户需要处理`);
  sendMessage('updateStatus', `开始关注，共 ${totalUsers} 个用户`, 'info');
  
  // 过滤掉已关注的用户
  logger.info('检查已关注用户列表...');
  const followedUsers = await getFollowedUsers();
  const beforeFilter = followQueue.length;
  followQueue = followQueue.filter(url => !followedUsers.includes(url));
  const skippedCount = beforeFilter - followQueue.length;
  
  if (skippedCount > 0) {
    logger.info(`已跳过 ${skippedCount} 个已关注的用户`);
  }
  
  if (followQueue.length === 0) {
    logger.success('所有用户都已关注，无需处理');
    sendMessage('updateStatus', '所有用户都已关注', 'success');
    isFollowing = false;
    sendMessage('followComplete');
    return;
  }
  
  logger.info(`剩余 ${followQueue.length} 个用户需要关注`);
  sendMessage('updateStatus', `剩余 ${followQueue.length} 个用户需要关注`, 'info');
  
  // 从存储中恢复统计信息，或初始化
  const statsResult = await chrome.storage.local.get(['successCount', 'failCount']);
  let successCount = statsResult.successCount || 0;
  let failCount = statsResult.failCount || 0;
  
  // 开始关注循环
  const followNext = async () => {
    if (!isFollowing) {
      logger.warning('关注流程已被停止');
      await chrome.storage.local.remove(['successCount', 'failCount']);
      stopFollow();
      sendMessage('updateStatus', `已停止关注 (成功: ${successCount}, 失败: ${failCount})`, 'info');
      sendMessage('followComplete');
      return;
    }
    
    if (currentIndex >= followQueue.length) {
      logger.info('========== 关注流程完成 ==========');
      logger.info(`成功: ${successCount} 个`);
      logger.info(`失败: ${failCount} 个`);
      await chrome.storage.local.remove(['successCount', 'failCount']);
      stopFollow();
      sendMessage('updateStatus', `关注完成 (成功: ${successCount}, 失败: ${failCount})`, 'success');
      sendMessage('followComplete');
      return;
    }
    
    const url = followQueue[currentIndex];
    logger.info(`\n--- 处理第 ${currentIndex + 1}/${followQueue.length} 个用户 ---`);
    
    // 检查当前页面，如果需要导航则导航
    const currentUrl = window.location.href.split('?')[0];
    const targetUrl = url.split('?')[0];
    
    if (currentUrl !== targetUrl) {
      logger.info(`需要导航到: ${url}`);
      await navigateToUser(url);
      // 导航后脚本会重新加载，状态会恢复
      return;
    }
    
    // 已在目标页面，处理关注
    const result = await followUser(url, actualKeyExpiry, currentIndex, followQueue.length);
    
    if (result) {
      successCount++;
    } else {
      failCount++;
    }
    
    // 保存统计信息
    await chrome.storage.local.set({ successCount, failCount });
    
    currentIndex++;
    await saveFollowState(); // 保存进度
    
    if (isFollowing && currentIndex < followQueue.length) {
      logger.info(`等待 ${interval} 秒后处理下一个用户...`);
      followInterval = setTimeout(followNext, followIntervalMs);
    } else {
      logger.info('========== 关注流程完成 ==========');
      logger.info(`成功: ${successCount} 个`);
      logger.info(`失败: ${failCount} 个`);
      await chrome.storage.local.remove(['successCount', 'failCount']);
      stopFollow();
      await chrome.storage.local.remove(['isFollowing', 'followQueue', 'currentIndex', 'followIntervalMs']);
      sendMessage('updateStatus', `关注完成 (成功: ${successCount}, 失败: ${failCount})`, 'success');
      sendMessage('followComplete');
    }
  };
  
  // 立即开始第一个
  logger.info('开始处理第一个用户...');
  followNext();
}

// 停止关注
async function stopFollow() {
  logger.warning('停止关注流程');
  isFollowing = false;
  if (followInterval) {
    clearTimeout(followInterval);
    followInterval = null;
  }
  await chrome.storage.local.remove(['isFollowing', 'followQueue', 'currentIndex', 'followIntervalMs']);
  sendMessage('updateStatus', '已停止关注', 'info');
}

// 日志系统
const logger = {
  log: function(message, type = 'info') {
    const timestamp = new Date().toLocaleTimeString('zh-CN');
    const logMessage = `[${timestamp}] ${message}`;
    console.log(logMessage);
    sendMessage('addLog', logMessage, type);
  },
  
  info: function(message) {
    this.log(message, 'info');
  },
  
  success: function(message) {
    this.log(message, 'success');
  },
  
  error: function(message) {
    this.log(message, 'error');
  },
  
  warning: function(message) {
    this.log(message, 'warning');
  }
};

// 发送消息到popup
function sendMessage(action, text, type) {
  chrome.runtime.sendMessage({
    action,
    text,
    type
  }).catch((error) => {
    // popup可能已关闭，忽略错误
    // 只在控制台记录，不抛出错误
    if (error.message && !error.message.includes('Receiving end does not exist')) {
      console.log('发送消息到popup失败（popup可能已关闭）:', error.message);
    }
  });
}

// 监听来自popup的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  try {
    if (message.action === 'startFollow') {
      logger.info('收到开始关注消息');
      startFollow(message.userList, message.interval, message.keyExpiry);
      sendResponse({ success: true });
    } else if (message.action === 'stopFollow') {
      logger.info('收到停止关注消息');
      stopFollow();
      sendResponse({ success: true });
    } else {
      sendResponse({ success: false, error: '未知的操作' });
    }
  } catch (error) {
    logger.error(`处理消息失败: ${error.message}`);
    sendResponse({ success: false, error: error.message });
  }
  return true; // 保持消息通道开放，允许异步响应
});

// 页面加载完成后初始化
async function initContentScript() {
  logger.info('抖音自动关注脚本已加载');
  // 尝试恢复未完成的任务
  try {
    await restoreFollowState();
  } catch (error) {
    logger.error(`初始化失败: ${error.message}`);
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initContentScript);
} else {
  // 如果页面已经加载完成，立即初始化
  initContentScript();
}

})(); // IIFE结束，避免重复加载导致的变量重复声明错误
